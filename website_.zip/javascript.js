document.write("<h3>Elias Michel Canva</h3>",
"<div>GitHub: michelcanvadev<br>",
"Twitter: @canvamicheldev<br>",
"Instagram: @eliasmichel<br>",
"linkedin: @canvamichelelias<br>",
"Localização: São Bernardo do Campo<div>");
